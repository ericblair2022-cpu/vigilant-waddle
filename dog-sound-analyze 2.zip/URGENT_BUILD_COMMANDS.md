# URGENT: BUILD AND UPLOAD TO APP STORE CONNECT

## IMMEDIATE COMMANDS TO RUN:

1. **Install EAS CLI (if not installed):**
```bash
npm install -g @expo/eas-cli
```

2. **Login to EAS:**
```bash
eas login
```
(Use your Expo account: ericblair@me.com)

3. **Build for iOS App Store:**
```bash
eas build --platform ios --profile production
```

4. **Submit to App Store Connect:**
```bash
eas submit --platform ios --profile production
```

## ALTERNATIVE IF ABOVE FAILS:

1. **Build locally and upload manually:**
```bash
eas build --platform ios --profile production --local
```

2. **Then upload the .ipa file manually through:**
- Xcode Organizer, OR
- Apple's Transporter app, OR
- App Store Connect web interface

## TROUBLESHOOTING:

If build fails, try:
```bash
expo install --fix
eas build --platform ios --profile production --clear-cache
```

## VERIFICATION:
After running these commands, check:
1. App Store Connect → My Apps → Dog Speak Analyzer → TestFlight
2. Look for build under "iOS Builds"
3. Process build for TestFlight testing

**RUN THESE COMMANDS NOW!**