import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import JungleBackground from '../components/JungleBackground';
import AnimalPicker from '../components/AnimalPicker';
import RecordButton from '../components/RecordButton';
import ResultCard from '../components/ResultCard';

import { analyzeAnimalSound, AnalysisResult, getTotalSoundsCount, getDailyNewSounds } from '../utils/animalSounds';

export default function Index() {
  const [isRecording, setIsRecording] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [selectedAnimal, setSelectedAnimal] = useState('dog');
  const [totalSounds] = useState(getTotalSoundsCount());
  const [dailyNewSounds] = useState(getDailyNewSounds());

  const handleRecordPress = async () => {
    if (isRecording) {
      setIsRecording(false);
      setIsAnalyzing(true);
      
      try {
        await new Promise(resolve => setTimeout(resolve, 1500 + Math.random() * 1500));
        const result = await analyzeAnimalSound(selectedAnimal);
        setAnalysisResult(result);
      } catch (error) {
        console.error('Analysis failed:', error);
      } finally {
        setIsAnalyzing(false);
      }
    } else {
      setIsRecording(true);
      setAnalysisResult(null);
    }
  };

  return (
    <JungleBackground>
      <StatusBar style="light" />
      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.header}>
          <View style={styles.titleContainer}>
            <Text style={styles.leafIcon}>🌿</Text>
            <Text style={styles.titleWhite}>TARZANA</Text>
          </View>
          <Text style={styles.subtitle}>AI-Powered Animal Language Analysis</Text>
          <Text style={styles.databaseTitle}>Tarzana AI Database</Text>
          <Text style={styles.databaseInfo}>🗄️ {totalSounds.toLocaleString()} sounds in database</Text>
          <Text style={styles.dailyInfo}>📈 +{dailyNewSounds} new sounds added daily from research</Text>
        </View>

        <AnimalPicker 
          selectedAnimal={selectedAnimal}
          onAnimalSelect={setSelectedAnimal}
        />

        <View style={styles.recordSection}>
          <RecordButton isRecording={isRecording} onPress={handleRecordPress} />
          
          {isRecording && (
            <View style={styles.statusContainer}>
              <Text style={styles.recordingText}>🎤 Listening for {selectedAnimal} sounds...</Text>
              <Text style={styles.statusSubtext}>Advanced AI detection active</Text>
            </View>
          )}
          
          {isAnalyzing && (
            <View style={styles.statusContainer}>
              <Text style={styles.analyzingText}>🔍 <Text style={styles.tarzanaAnalyzing}>TARZANA AI analyzing</Text>...</Text>
              <Text style={styles.statusSubtext}>Matching with {selectedAnimal} database recordings</Text>
            </View>
          )}
        </View>

        {analysisResult && (
          <View>
            <ResultCard
              meaning={analysisResult.sound.meaning}
              confidence={analysisResult.confidence}
              emotion={analysisResult.sound.emotion}
              soundName={analysisResult.sound.sound_name}
              detectedAnimal={analysisResult.detectedAnimal}
              aiResearch={analysisResult.aiResearch}
              isAnimal={analysisResult.isAnimal}
              animalSaying={analysisResult.animalSaying}
              expression={analysisResult.sound.expression}
              matchSource={analysisResult.matchSource}
            />
            

          </View>
        )}
      </ScrollView>
    </JungleBackground>
  );
}

const styles = StyleSheet.create({
  scrollContent: { 
    flexGrow: 1, 
    paddingTop: 60,
  },
  header: { 
    alignItems: 'center', 
    marginBottom: 30, 
    paddingHorizontal: 20,
    paddingVertical: 20,
  },
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8
  },
  leafIcon: {
    fontSize: 36,
    marginRight: 8,
    opacity: 0.8,
  },
  titleWhite: {
    fontSize: 36,
    fontWeight: 'bold',
    color: '#ffffff',
    textShadowColor: 'rgba(0,0,0,0.5)',
    textShadowOffset: {width: 2, height: 2},
    textShadowRadius: 4,
    letterSpacing: 3
  },
  subtitle: { 
    fontSize: 16, 
    color: '#e8f5e8', 
    textAlign: 'center', 
    lineHeight: 22,
    marginBottom: 8
  },
  databaseTitle: {
    fontSize: 18,
    color: '#ffffff',
    textAlign: 'center',
    fontWeight: 'bold',
    marginBottom: 8
  },
  databaseInfo: {
    fontSize: 14,
    color: '#ffeb3b',
    textAlign: 'center',
    fontWeight: '600',
    marginBottom: 4
  },
  dailyInfo: {
    fontSize: 12,
    color: '#e8f5e8',
    textAlign: 'center',
    fontWeight: '500'
  },
  recordSection: { 
    alignItems: 'center', 
    marginBottom: 40,
    marginHorizontal: 20,
    paddingVertical: 20,
  },
  statusContainer: {
    alignItems: 'center',
    marginTop: 20,
  },
  recordingText: { 
    fontSize: 18, 
    color: '#ffffff', 
    fontWeight: '600',
    textShadowColor: 'rgba(0,0,0,0.5)',
    textShadowOffset: {width: 1, height: 1},
    textShadowRadius: 3
  },
  analyzingText: { 
    fontSize: 18, 
    color: '#ffffff', 
    fontWeight: '600',
    textShadowColor: 'rgba(0,0,0,0.5)',
    textShadowOffset: {width: 1, height: 1},
    textShadowRadius: 3
  },
  tarzanaAnalyzing: {
    color: '#ffeb3b',
    fontWeight: 'bold'
  },
  statusSubtext: {
    fontSize: 14,
    color: '#e8f5e8',
    marginTop: 5,
    textAlign: 'center'
  },
});