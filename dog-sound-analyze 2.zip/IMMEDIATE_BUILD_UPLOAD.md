# IMMEDIATE BUILD AND UPLOAD TO APP STORE CONNECT

## CRITICAL: Run these commands NOW to upload your build!

### Step 1: Install EAS CLI (if not already installed)
```bash
npm install -g @expo/eas-cli
```

### Step 2: Login to EAS
```bash
eas login
# Use your Apple ID: ericblair2022@gmail.com
```

### Step 3: Build for iOS App Store
```bash
eas build --platform ios --profile production
```
**This will take 10-15 minutes. Wait for it to complete!**

### Step 4: Submit to App Store Connect
```bash
eas submit --platform ios --profile production
```

### Step 5: Verify in App Store Connect
1. Go to https://appstoreconnect.apple.com
2. Login with ericblair2022@gmail.com
3. Go to "My Apps" → "Dog Speak Analyzer"
4. Check "TestFlight" tab - your build should appear there
5. Go to "App Store" tab and select your build for review

## If Build Fails:
```bash
# Check build status
eas build:list

# View build logs
eas build:view [BUILD_ID]
```

## Your App Details:
- Bundle ID: com.ericblair.dogspeakanalyzer
- Apple ID: ericblair2022@gmail.com
- Team ID: R7SBX4HG87
- App Store Connect ID: M384PZAACT

**RUN THE COMMANDS ABOVE NOW!**